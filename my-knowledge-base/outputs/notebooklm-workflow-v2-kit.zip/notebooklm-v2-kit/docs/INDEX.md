---
title: 知識庫索引
date: 2026-05-14
tags: [pkm/obsidian]
type: reference
status: processed
---

# 知識庫索引

> 此索引由 AI 維護。最後更新：2026-05-14（knowledge-organizer：新增 gemini-cli-subagent；更新 harness-engineering（五維度 Checklist + Managed Agents 更新 + 越做越薄原則）、dual-tool-strategy（補充連結））

## 進行中專案

| 專案 | 目標 | 狀態 |
|------|------|------|
| （尚無進行中專案） | | |

## AI 工具應用 — Claude Code

| 條目 | 摘要 |
|------|------|
| [[claude-code-glossary]] | 38 個 AI 開發關鍵詞速查（LLM / Token / Context Window / Agent / MCP / Harness）|
| [[claude-code-tools]] | Claude Code 內建 Tools 使用邏輯（Read/Glob/Grep/Edit/Agent）與 Prompt 反推技巧 |
| [[claude-code-context-management]] | Context 管控全攻略：六成存檔 + /clear 重開，不依賴 Auto Compaction |
| [[claude-code-file-management]] | 哪些設定檔該 commit：四層架構說明（Managed/User/Project/Local）|
| [[claude-md-guide]] | CLAUDE.md 撰寫技巧：8 個讓 AI 真正聽話的具體規則寫法 |
| [[claude-code-commands-2026]] | 2026 上半年 12 個新命令解析：/ultrareview、/goal、/batch + Skills 統一架構 |
| [[claude-code-commands-reference]] | 三層命令體系速查表（13 大類 Slash 指令 + 快捷鍵）|

## 知識精粹（Synthesis）

| 條目 | 整合來源 | 精粹論點 |
|------|---------|---------|
| [[synthesis-ai-dev-workflow-frameworks]] | Superpowers / gstack / spec-driven / Skills 生態（4 篇）| AI 代理的瓶頸是工作流架構，gstack 管戰略、Superpowers 管紀律，最強組合是兩者並用 |

## AI 工具應用 — 工作流搭配

| 條目 | 摘要 |
|------|------|
| [[superpowers-gstack-workflow]] | Superpowers + gstack 搭配實戰：37 技能路由表 + 5 個交接點 + CLAUDE.md 配置模板 |

## AI 工具應用 — Agent 設計

| 條目 | 摘要 |
|------|------|
| [[harness-engineering]] | Harness Engineering：Guides×Sensors 框架，護城河在環境而非模型 |
| [[agents-md-guide]] | AGENTS.md 完整指南：設計原則、效果研究（+4% vs -3%）、AI-Ready 倉庫清單 |
| [[zerospec]] | ZeroSpec：零依賴 Markdown 框架，AI 開工前的技術交接單 |
| [[agent-skill-design-patterns]] | Google 5 大 Skill 設計模式：單一工具/流程串接/路由/並行/反思 |
| [[superpowers-framework]] | Superpowers：15 個 Skill 強制 TDD 工程紀律，brainstorming → subagent-driven-development |
| [[gstack-framework]] | gstack：YC CEO Garry Tan 開源，23+ Skill 完整 Sprint 流程（Think→Plan→Build→Review→Test→Ship→Reflect）|
| [[spec-driven-ai-workflow]] | 規格驅動工作流：spec-kit / OpenSpec（規格先行）+ Superpowers（工程紀律）|
| [[agentic-ai-learning-roadmap]] | AI Agent 7 階段學習地圖：Track A（CLI）/ Track B（Builder），含時程估算 |

## AI 工具應用 — Claude Skills

| 條目 | 摘要 |
|------|------|
| [[claude-skills-guide]] | Claude Skills 完整指南：能力包型 + 軟編排型，比 MCP 更省 Token |
| [[claude-skills-asset-building]] | Skills 從指令到資產：MAPS 框架 + 漸進式披露機制 |
| [[claude-skills-deep-dive]] | Progressive Disclosure 三層機制 + Skills vs MCP vs Custom Commands vs Subagents 比較 |
| [[claude-skills-ecosystem]] | GitHub 16 個高 star Skills Repo 四檔分類 + 三代安裝演進（git clone→/plugin→gh skill）|
| [[agent-skills-vs-mcp]] | Skills vs MCP 選擇判斷：靜態知識→Skills，即時外部資料→MCP |
| [[addyosmani-engineering-skills]] | Addy Osmani 20 個工程師 Skill：把隱性直覺變成 AI 可執行 checklist |
| [[agent-skills-toolkit]] | agent-skills：22 個 Skill 完整開發生命週期（DEFINE→PLAN→BUILD→VERIFY→REVIEW→SHIP），含 Google 工程文化精華 |
| [[ai-pair-skill]] | AI-Pair：Claude + GPT + Gemini 異構審查團隊（一個創作，兩個審查）|
| [[claude-pilot-suite]] | Claude Pilot Suite：三模式執行手冊（Haiku 省 70-85% / Sonnet / Opus）|
| [[obsidian-visual-skills]] | Obsidian Visual Skills Pack：Canvas / Excalidraw / Mermaid 自動生成 |

## AI 工具應用 — 工作流策略

| 條目 | 摘要 |
|------|------|
| [[dual-tool-strategy]] | 雙工具策略：Gemini CLI 探索（免費）+ Claude Code 執行，省 60-70% 費用 |
| [[gemini-cli-subagent]] | Gemini CLI 接入 Claude Code：省 Token 的具體設定、安全配置（excludeTools）+ 三種分工場景 |
| [[obsidian-web-clipper]] | Obsidian 官方瀏覽器擴充，一鍵存為本地 Markdown，支援 AI 自動摘要 |

## 個人知識管理（PKM）

| 條目 | 摘要 |
|------|------|
| [[karpathy-knowledge-base-method]] | Karpathy 三資料夾法：人負責輸入，AI 負責整理，知識庫自動演化 |
| [[karpathy-no-obsidian-setup]] | 不用 Obsidian 的極簡版：三資料夾 + CLAUDE.md 即可跑通 |
| [[claude-code-obsidian-setup]] | Claude Code + Obsidian 完整建構指南，含 Web Clipper 整合步驟 |
| [[wenhao-yu-ai-workflow]] | WenHao Yu 個人 AI 工作流：每天兩字觸發 8 步驟 daily brief |
| [[cognitive-hub]] | Cognitive Hub：記憶先於行動，外部化活記憶設計模式 |
| [[obsidian-visual-skills]] | Obsidian Visual Skills Pack：視覺圖表自動生成（見 AI Skills 區塊）|
| [[obsidian-knowledge-base-planning]] | 五篇文章的共通方法 + MAPS 資產化路線圖（5A+ 分階段實施計劃）|
| [[query-strategy]] | 知識庫查詢策略：依規模選擇查詢方式（直接讀／knowledge-synthesizer 壓縮／先搜尋再讀）|

## 知識資產化方法論

| 條目 | 摘要 |
|------|------|
| [[maps-framework]] | MAPS™ 四維羅盤：Mindset × Architecture × Prompt × Systems |
| [[enterprise-rag]] | 企業私有知識庫 RAG 實作：OpenClaw + 向量資料庫，資料不外流 |

## 軟體開發 — B2B Manager

| 條目 | 摘要 |
|------|------|
| [[b2b-manager/INDEX]] | B2B Manager 完整知識庫入口（Flutter Web 石油管理平台）|
| [[b2b-manager/overview]] | 技術棧、套件版本、部署方式 |
| [[b2b-manager/architecture]] | 目錄結構、TaskManager、DataTable 高頻回歸規則 |
| [[b2b-manager/dev-workflow]] | flutter run / build / test 常用指令 |
| [[b2b-manager/api]] | 17 個 API 模組清單 |
| [[b2b-manager/pages]] | 各頁面架構文件索引 |
| [[b2b-manager/bugs]] | Bug 記錄 + 高頻回歸模式 |
| [[b2b-manager/tasks]] | 任務狀態（待實作：sort_data_tables、batch_edit_car_undo）|
| [[b2b-manager/troubleshooting]] | 6 項常見錯誤 + 5 項 DataTable 問題速查（build_runner / TaskManager / DataCell）|
